<?php
session_start();
if($_SESSION["myusername"] == null){
header("location: home.php");
  
}
else {

}
?>

<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Homeless Support Portal</title>
    
    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css">

    <!-- Custom styles for this template -->
    <link href="css/freelancer.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/style.css" />
	
	<form action="/your-server-side-code" method="POST">
  <script
    src="https://checkout.stripe.com/checkout.js" class="stripe-button"
    data-key="pk_test_6pRNASCoBOKtIshFeQd4XMUh"
    data-amount="999"
    data-name="Stripe.com"
    data-description="Widget"
    data-image="https://stripe.com/img/documentation/checkout/marketplace.png"
    data-locale="auto"
    data-zip-code="true">
  </script>
</form>
  </head>

  <body id="page-top">

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light fixed-top" id="mainNav">
      <div class="container">
        
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          Menu
          <i class="fa fa-bars"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#home">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#aboutus">About Us</a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#onlineshop">Online Shop</a>
            </li>
			<li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#donation">Donation</a>
            </li>
			<li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#successfulstories">Successful Stories</a>
            </li>
			<li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#messageboard">Message Board</a>
            </li>
			<li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#helpfullinks">Helpful Links</a>
            </li>
          </ul>
        </div>
            <p>
            <a href="home.php" class="btn btn-info btn-lg">
          <span class="glyphicon glyphicon-log-out"></span> Log out
        </a>
        </p>
      </div>
    </nav>

    <!-- Header -->
    <header class="masthead" id="home">
      <div class="container">
        <img class="img-fluid" src="photo4.jpeg" alt="">
        <div class="intro-text">
          <span class="name">Homeless Support</span>
          <hr class="star-light">
          <span class="skills">Sponsor - Donate - Message</span>
        </div>
      </div>
    </header>
  
    <!-- About Section -->
    <section class="success" id="aboutus">
      <div class="container">
        <h2 class="text-center">About Us</h2>
        <hr class="star-light">
        <div class="row">
            <p>Homelessness is a huge problem in Ireland with 8,270 homeless people in August 2017. This figures aren’t just adults with one in three in emergency accommodation is a child, which can be so stressful for the family and the child which can lead to problems in the future with the child. The facts and figures you see aren’t just people on the streets or in emergency accommodation there is the hidden homelessness with is people who are living in squats or sofa surfing.
             Also not included in the figures are woman and children staying in domestic violence refuges.We built this website to help the constant problem of homelessness which is only ever increasing.What makes us different to other charity’s?</p>
			<ul>
			<li>Well we give the option to give money to just one homeless person rather than donating to the charity in general which you are unsure who’s getting the money.</li>
			<li>All donations to the individual homeless person are unbiased.</li>
			<li>We also give the option to purchase hats and scarfs for the homeless people.</li>
			</ul>  
          </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section id="onlineshop">
      <div class="container">
        <h2 class="text-center">Online Shop</h2>
		<hr class="star-primary">
        <div class="row">
          <div class="col-sm-4 portfolio-item">
            <a class="portfolio-link" href="#portfolioModal1" data-toggle="modal">
              <div class="caption">
                <div class="caption-content">
                </div>
              </div>
              <img class="img-fluid" src="img/hat.jpg" alt="" style="width:300px;height:300px">
			   <p>
                <!-- Provides extra visual weight and identifies the primary action in a set of buttons -->
                <button type="button" class="btn btn-primary">Buy it now</button>
            </p>
            </a>
          </div>
          <div class="col-sm-4 portfolio-item">
            <a class="portfolio-link" href="#portfolioModal2" data-toggle="modal">
              <div class="caption">
                <div class="caption-content">
                </div>
              </div>
              <img class="img-fluid" src="img/jacket.jpg" alt="" style="width:300px;height:300px">
			  <br>
			   <p>
                <!-- Provides extra visual weight and identifies the primary action in a set of buttons -->
                <button type="button" class="btn btn-primary">Buy it now </button>
            </p>
            </a>
          </div>
          <div class="col-sm-4 portfolio-item">
            <a class="portfolio-link" href="#portfolioModal3" data-toggle="modal">
              <div class="caption">
                <div class="caption-content">
                </div>
              </div>
              <img class="img-fluid" src="img/trousers.jpg" alt="modal" style="width:300px;height:300px">
			  			   <p>
                <!-- Provides extra visual weight and identifies the primary action in a set of buttons -->
                <button type="button" class="btn btn-primary">Buy it now </button>
            </p>
            </a>
          </div>
          <div class="col-sm-4 portfolio-item">
            <a class="portfolio-link" href="#portfolioModal4" data-toggle="modal">
              <div class="caption">
                <div class="caption-content">
                </div>
              </div>
              <img class="img-fluid" src="img/gloves.jpg" alt="" style="width:300px;height:300px">
			  			   <p>
                <!-- Provides extra visual weight and identifies the primary action in a set of buttons -->
                <button type="button" class="btn btn-primary">Buy it now </button>
            </p>
            </a>
          </div>
          <div class="col-sm-4 portfolio-item">
            <a class="portfolio-link" href="#portfolioModal5" data-toggle="modal">
              <div class="caption">
                <div class="caption-content">
                </div>
              </div>
              <img class="img-fluid" src="img/sleepingbag.jpg" alt=""  style="width:300px;height:300px">
			  			   <p>
                <!-- Provides extra visual weight and identifies the primary action in a set of buttons -->
                <button type="button" class="btn btn-primary">Buy it now </button>
            </p>
            </a>
          </div>
          <div class="col-sm-4 portfolio-item">
            <a class="portfolio-link" href="#portfolioModal6" data-toggle="modal">
              <div class="caption">
                <div class="caption-content">
                </div>
              </div>
              <img class="img-fluid" src="img/tent.jpg" alt="" style="width:300px;height:300px">
			  			   <p>
                <!-- Provides extra visual weight and identifies the primary action in a set of buttons -->
                <button type="button" class="btn btn-primary">Buy it now </button>
            </p>
            </a>
          </div>
        </div>
      </div>
    </section>
	
	<section class="success" id="donation">
		<div class="container">
			<h2 class="text-center">Donation</h2>
			<hr class="star-light">
			<div id="solo" class="text-center"> 
			  <h5 id = "Single" >Donate to your Sponsor</h5>
			  <a class="portfolio-link" href="#portfolioModal7" data-toggle="modal">
			  <button type="button" class="btn btn-primary">Donate now </button>
			  </a>
			  </div>
			  <div id = "Fam" class="text-center">
			    <h5 id = "Family">Donate to a Family</h5>
			    <a class="portfolio-link" href="#portfolioModal8" data-toggle="modal">
			    <button type="button" class="btn btn-primary">Donate now </button>
			    </a>
			  </div>
			</div>
	</section>
	
	<section id="successfulstories">
		<div class="container" style="width:100%">
			<h2 class="text-center">Successful Stories</h2>
			<hr class="star-primary">
			<div>
			<h3 id = "Casandra">Casandra</h3>
			</div>
			<div class = "row" style="width:100%">
			<div id="markpic" style="width:25%">
			<img src="photo1.jpg">
			</div>
			<div id="marktxt" style="width:75%">
			<p>"The Homeless Supoort Portal saved my life, before i lived on the streets i was an acountaint at Bank of Ireland
			 Now i live under the Shelter of The GPO. The nights are cold but thanks to the help of some generous sponsors i now own
			 a sleeping bag and warm clothes, I usually recive around €12 a week which lets me buy some food. Thank you So much HSP."</p>
			</div>
	  </div>
			
      <div>
			<h3 id = "James">James</h3>
			</div>
			<div class = "row" style="width:100%">
			<div id="markpic" style="width:25%">
			<img src="photo2.jpeg">
			</div>
			<div id="marktxt" style="width:75%">
			<p>"The Homeless Supoort Portal gave me the opptunity to grow as a person and achieve my goals and actually beating 
			 my deamons and giving me the optunity to give me a roof over my head and gave me food to eat, since that 
			 difficult time in my life I studied in the National College of Ireland and I am now an accountant at KPMG. 
			 I couldnt be happier with my life now. Thanks Homeless Support Portal"</p>
			</div>
	  </div>
			
      <div>
			<h3 id = "Lesbo">Lesbo</h3>
			</div>
			<div class = "row" style="width:100%">
			<div id="markpic" style="width:25%">
			<img src="photo3.jpg">
			</div>
			<div id="marktxt" style="width:75%">
			<p>"The Homeless Supoort Portal gave people like myself a chance in the god damn crule world, I didnt know who ma da was and my mam was a crack whore, 
			 lucky for me and I got out of this bad bad environmentand went to the streets where I was a prostitute, 
			 dam some fellas gave me a lot of crack, I mean cash! but the homeless Suport portal gave me cash with out having to take my clothes off. 
			 I am an independent black woman who dont need no man! I got to meet the love of my life Mary in the homeless support portal, 
			 She was ma sponcer and gave me money but now shes ma lover and my money supplier. 
			 God bless Ireland. yup the d7"</p>
			</div>
	  </div>
			</div>
	</section>

	<section class = "success" id="messageboard" >
		<div class="container">
			<h2 class="text-center">Message Board</h2>
			<hr class="star-light">
			<style>
input[type=text], select {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}

input[type=submit] {
    width: 100%;
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

</style>
<body>
<form name="sentMessage" id="contactForm" novalidate>
              <div class="control-group">
                <div class="form-group floating-label-form-group controls">
                  <label>Name</label>
                  <input class="form-control" id="name" type="name" placeholder="Name" required data-validation-required-message="Please enter your name.">
                  <p class="help-block text-danger"></p>
                </div>
              </div>
              <div class="control-group">
                <div class="form-group floating-label-form-group controls">
                  <label>Email Address</label>
                  <input class="form-control" id="email" type="email" placeholder="Email Address" required data-validation-required-message="Please enter your email address.">
                  <p class="help-block text-danger"></p>
                </div>
              </div>
              <div class="control-group">
                <div class="form-group floating-label-form-group controls">
                  <label>Message</label>
                  <textarea class="form-control" id="message" rows="5" placeholder="Message" required data-validation-required-message="Please enter a message."></textarea>
                  <p class="help-block text-danger"></p>
                </div>
              </div>
  
     <div id="success">
              <div class="form-group">
                <button type="submit" class="btn btn-primary" id="sendMessageButton">Send</button>
        </div>
</div>
  </form>


	</section>
	
	<section id="helpfullinks">
		<div class="container">
			<h2 class="text-center">Helpful Links</h2>
			<hr class="star-primary">
			<div>
			<h3 id = "Simon">Simon Community</h3>
			</div>
			<div class="row" id="clearfix">
			<div style="width:50%; float:left">
			<img src="img/SimonLogo.png">
			</div>
			<div style= "float:right">
			<p>Dublin Simon Community work to prevent and address homelessness in Dublin, Kildare, Wicklow and Meath. We provide services at all stages of homelessness and enable people to move to a place they can call home.<a href="http://www.dubsimon.ie/"> Click on the text to visit their site.</a></p>
			</div>
			</div>
			
			<div>
			<h3 id = "Focus">Focus Ireland</h3>
			</div>
			<div class="row">
			<div style="width:50%;" "float:left;">
			<img src="img/Focus.jpg" style="width:200px;" "height:200px;">
			</div>
			<div style= "float:right;">
			<p>Focus Ireland helps prevent families, young people and individuals from having to first experience homelessness if possible. For those currently experiencing homelessness, we identify the best available supports and options to aid them on their journey out of homelessness. Another key aspect of our work is supporting those at risk of homelessness again in the future, to minimise the risk, by providing excellent tenancy supports.<a href="https://www.focusireland.ie/"> Click on the text to visit their site.</a></p>
			</div>
			</div>
			
			<div>
			<h3 id = "Peter">Peter McVerry Trust</h3>
			</div>
			<div class="row">
			<div style="width:50%;" "float:left;">
			<img src="img/peter.jpg" style="width:200px;" "height:200px;">
			</div>
			<div style= "float:right; position: static ">
			<p>Fr Peter McVerry has been working with young people experiencing homelessness for more than 30 years. In 1974, Fr McVerry moved to Summerhill in Dublin’s north inner-city where he witnessed firsthand the problems of homelessness and deprivation. In 1979, he opened a small hostel to provide accommodation for homeless boys between the ages of 12-16. Four years later, he founded The Arrupe Society, a charity to provide housing and support for young people experiencing homelessness as a response to the growing numbers of individuals becoming homeless in Dublin.<a href="https://www.pmvtrust.ie/"> Click on the text to visit their site.</a></p>
			</div>
			</div>
			</div>
		</section>
    <!-- Footer -->
    <footer class="text-center">
      <div class="footer-above">
        <div class="container">
          <div class="row">
            <div class="footer-col col-md-4">
              <h3>Location</h3>
              <p>National College of Ireland
                <br>IFSC, Dublin 1, Ireland</p>
            </div>
            <div class="footer-col col-md-4">
              <h3>Around the Web</h3>
              <ul class="list-inline">
                <li class="list-inline-item">
                  <a class="btn-social btn-outline" href="https://www.facebook.com/Homelesssupportportal/ ">
                    <i class="fa fa-fw fa-facebook"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a class="btn-social btn-outline" href="https://twitter.com/homelessupport">
                    <i class="fa fa-fw fa-twitter"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a class="btn-social btn-outline" href="https://www.linkedin.com/in/homeless-support-portal/">
                    <i class="fa fa-fw fa-linkedin"></i>
                  </a>
                </li>
              </ul>
            </div>
            <div class="footer-col col-md-4">
              <h3>Homeless in Ireland</h3>
              <p>Homeless is an issue here in Dublin and we need your help to solve it...</p>
            </div>
          </div>
        </div>
      </div>
      <div class="footer-below">

            <div class="col-lg-12">
              Copyright &copy; Keith Hui(Co-Leader)
			  <br>Ailis Curan (Co-Leader)
			  <br> Richard St Lawrence (Developer)
			  <br> Jonathan Harte (Tester)
            </div>
      </div>
    </footer>

    <!-- Scroll to Top Button (Only visible on small and extra-small screen sizes) -->
    <div class="scroll-top d-lg-none">
      <a class="btn btn-primary js-scroll-trigger" href="#page-top">
        <i class="fa fa-chevron-up"></i>
      </a>
    </div>

    <!-- Portfolio Modals -->
    <div class="portfolio-modal modal fade" id="portfolioModal1" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="close-modal" data-dismiss="modal">
            <div class="lr">
              <div class="rl"></div>
            </div>
          </div>
          <div class="container">
            <div class="row">
              <div class="col-lg-8 mx-auto">
                <div class="modal-body">
                  <h2>Thinsulate Hat</h2>
                  <hr class="star-primary">
                  <img class="img-fluid img-centered" src="img/hat.jpg" alt="">
                  <p>This hat can give someone heat in the cold months and would make a lovely present for a homeless person
                  with the low price of $8 making this hat a very affordable gift. </p>
                    <li>Price: $8
                    </li>
                    <li>Make: Thinsulate
                    </li>
                    <li>Fabric: Wool
                    </li>
                    <li>
                      Colour:Black
                    </li>
                  </ul>
                  <button class="btn btn-success" type="button" data-dismiss="modal" onclick="" class="portfolio-link" href="#portfolioModal24" data-toggle="modal">
                    <i class="fa fa-times"></i>
                    Buy Now</button>
                  <button class="btn btn-success" type="button" data-dismiss="modal">
                    <i class="fa fa-times"></i>
                    Back out</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="portfolio-modal modal fade" id="portfolioModal2" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="close-modal" data-dismiss="modal">
            <div class="lr">
              <div class="rl"></div>
            </div>
          </div>
          <div class="container">
            <div class="row">
              <div class="col-lg-8 mx-auto">
                <div class="modal-body">
                 <h2>Helly Hansen Coat</h2>
                  <hr class="star-primary">
                  <img class="img-fluid img-centered" src="img/jacket.jpg" alt="">
                  <p>This coat can give someone heat in the cold months and would make a lovely present for a homeless person
                  with the good price of $45 making this coat a coat that they can use year after year.</p>
                    <li>Price: $45
                    </li>
                    <li>Make: Helly Hansen
                    </li>
                    <li>Fabric: Waterproof Cotton
                    </li>
                    <li>
                      Colour:Black
                    </li>
                  </ul>
                  <button class="btn btn-success" type="button" data-dismiss="modal" onclick="" class="portfolio-link" href="#portfolioModal24" data-toggle="modal">
                    <i class="fa fa-times"></i>
                    Buy Now</button>
                  <button class="btn btn-success" type="button" data-dismiss="modal">
                    <i class="fa fa-times"></i>
                    Back out</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="portfolio-modal modal fade" id="portfolioModal3" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="close-modal" data-dismiss="modal">
            <div class="lr">
              <div class="rl"></div>
            </div>
          </div>
          <div class="container">
            <div class="row">
              <div class="col-lg-8 mx-auto">
                <div class="modal-body">
                  <h2>Helly Hansen Trousers</h2>
                  <hr class="star-primary">
                  <img class="img-fluid img-centered" src="img/trousers.jpg" alt="">
                  <p>This Trousers can give someone heat in the cold months and would make a lovely present for a homeless person
                  with the low price of $50 making these trousers a very practical gift which will do tham in years to come.</p>
                    
                    <li>Price: $50
                    </li>
                    <li>Make: Helly Hansen
                    </li>
                    <li>Fabric: Waterproof Cotton
                    </li>
                    <li>
                      Colour:Grey
                    </li>
                  </ul>
                  <button class="btn btn-success" type="button" data-dismiss="modal" onclick="" class="portfolio-link" href="#portfolioModal24" data-toggle="modal">
                    <i class="fa fa-times"></i>
                    Buy Now</button>
                  <button class="btn btn-success" type="button" data-dismiss="modal">
                    <i class="fa fa-times"></i>
                    Back out</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="portfolio-modal modal fade" id="portfolioModal4" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="close-modal" data-dismiss="modal">
            <div class="lr">
              <div class="rl"></div>
            </div>
          </div>
          <div class="container">
            <div class="row">
              <div class="col-lg-8 mx-auto">
                <div class="modal-body">
                 <h2>Lovarzi Gloves</h2>
                  <hr class="star-primary">
                  <img class="img-fluid img-centered" src="img/gloves.jpg" alt="">
                  <p>These pair of gloves can give someone heat in the cold months and would make a lovely present for a homeless person
                  with the low price of $4 making these gloves a very practical gift which will do the homeless people in the winter</p>
                    
                    <li>Price: $4
                    </li>
                    <li>Make: Lovarzi 
                    </li>
                    <li>Fabric: Cotton
                    </li>
                    <li>
                      Colour:Grey
                    </li>
                  </ul>
                  <button class="btn btn-success" type="button" data-dismiss="modal" onclick="" class="portfolio-link" href="#portfolioModal24" data-toggle="modal">
                    <i class="fa fa-times"></i>
                    Buy Now</button>
                  <button class="btn btn-success" type="button" data-dismiss="modal">
                    <i class="fa fa-times"></i>
                    Back out</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="portfolio-modal modal fade" id="portfolioModal5" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="close-modal" data-dismiss="modal">
            <div class="lr">
              <div class="rl"></div>
            </div>
          </div>
          <div class="container">
            <div class="row">
              <div class="col-lg-8 mx-auto">
                <div class="modal-body">
                  <h2>Venom Sleeping Bag</h2>
                  <hr class="star-primary">
                  <img class="img-fluid img-centered" src="img/sleepingbag.jpg" alt="">
                  <p>This sleeping bag can give someone heat and warmth during the night in the cold months and would make a lovely present for a homeless person
                  with the price of $50 making this sleeping bag a very practical gift which will do the homeless people in the winter</p>
                    
                    <li>Price: $50
                    </li>
                    <li>Make: Venom 
                    </li>
                    <li>Fabric: Cotton
                    </li>
                    <li>
                      Colour:Grey and Blue
                    </li>
                  </ul>
                  <button class="btn btn-success" type="button" data-dismiss="modal" onclick="" class="portfolio-link" href="#portfolioModal24" data-toggle="modal">
                    <i class="fa fa-times"></i>
                    Buy Now</button>
                  <button class="btn btn-success" type="button" data-dismiss="modal">
                    <i class="fa fa-times"></i>
                    Back out</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="portfolio-modal modal fade" id="portfolioModal6" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="close-modal" data-dismiss="modal">
            <div class="lr">
              <div class="rl"></div>
            </div>
          </div>
          <div class="container">
            <div class="row">
              <div class="col-lg-8 mx-auto">
                <div class="modal-body">
                <h2>Regatta Tent</h2>
                  <hr class="star-primary">
                  <img class="img-fluid img-centered" src="img/tent.jpg" alt="">
                  <p>The Tent is one of our more expesive gifts which can give someone heat and warmth during the night in the cold months and would make a lovely present for a homeless person
                  with the price of $100 making this tent an increadable gift which will do the homeless people in the winter and for the folloing years to come.</p>
                    
                    <li>Price: $100
                    </li>
                    <li>Make: Regatta
                    </li>
                    <li>Fabric: Cotton
                    </li>
                    <li>
                      Colour:Blue and Orange
                    </li>
                  </ul>
                  <button class="btn btn-success" type="button" data-dismiss="modal" onclick="" class="portfolio-link" href="#portfolioModal24" data-toggle="modal">
                    <i class="fa fa-times"></i>
                    Buy Now</button>
                  <button class="btn btn-success" type="button" data-dismiss="modal">
                    <i class="fa fa-times"></i>
                    Back out</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <div class="portfolio-modal modal fade" id="portfolioModal7" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="close-modal" data-dismiss="modal">
            <div class="lr">
              <div class="rl"></div>
            </div>
          </div>
          <div class="container">
            <div class="row">
              <div class="col-lg-8 mx-auto">
                <div class="modal-body">
                <h2>Donate to your sponsor</h2>
                  <hr class="star-primary">
                  <img class="img-fluid img-centered" src="img/homeless.png" alt="">
                  <p>Donate to your sponsor. All donations will be sent to them in the next few days. You will receive a confirmation email that your donation has been completed</p>
                  </ul>
                  <button class="btn btn-success" type="button" data-dismiss="modal" onclick="" class="portfolio-link" href="#portfolioModal22" data-toggle="modal">
                    <i class="fa fa-times"></i>
                    Donate Now</button>
                  <button class="btn btn-success" type="button" data-dismiss="modal">
                    <i class="fa fa-times"></i>
                    Back Out</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    
    
        <div class="portfolio-modal modal fade" id="portfolioModal8" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="close-modal" data-dismiss="modal">
            <div class="lr">
              <div class="rl"></div>
            </div>
          </div>
              <div class="container">
            <div class="row">
              <div class="col-lg-8 mx-auto">
                <div class="modal-body">
                <h2>Donate to a family</h2>
                  <hr class="star-primary">
                  <img class="img-fluid img-centered" src="img/homelessfamily.jpg" alt="">
                  <p>Donate to your sponsor. All donations will be sent to them in the next few days. You will receive a confirmation email that your donation has been completed</p>
                  </ul>
                 <button class="btn btn-success" type="button" data-dismiss="modal" onclick="" class="portfolio-link" href="#portfolioModal23" data-toggle="modal">
                    <i class="fa fa-times"></i>
                    Donate Now</button>
                  <button class="btn btn-success" type="button" data-dismiss="modal">
                    <i class="fa fa-times"></i>
                    Back Out</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    
    
    <div class="portfolio-modal modal fade" id="portfolioModal22" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="close-modal" data-dismiss="modal">
            <div class="lr">
              <div class="rl"></div>
            </div>
          </div>
          <div class="container">
            <div class="row">
              <div class="col-lg-8 mx-auto">
                <div class="modal-body">
                
                <form action"" method="POST" ID="Payment-form">
                  <span class="payment-errors"></span>
                  
                  <div class="form-row">
                    <label>
                      <span>Card Number</span>
                      <input type="text" size="20" data-stripe="number"/>
                       </label>
                     </div>
                     
                     <div class="form-row">
                    <label>
                      <span>CVC</span>
                      <input type="text" size="4" data-stripe="cvc"/>
                       </label>
                     </div>
                     
                     <div class="form-row">
                    <label>
                      <span>Expiry Date(MM/YYYY)</span>
                      <input type="text" size="2" data-stripe="exp-month"/>
                       </label>
                       <span> / </span>
                       <input type="text" size="4" data-stripe="exp-year"/>
                     </div>
                     
                     <button type="submit">Submit Payment</button>
                     </form>
                     
                  
                </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <div class="portfolio-modal modal fade" id="portfolioModal23" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="close-modal" data-dismiss="modal">
            <div class="lr">
              <div class="rl"></div>
            </div>
          </div>
          <div class="container">
            <div class="row">
              <div class="col-lg-8 mx-auto">
                <div class="modal-body">
                
                <form action"" method="POST" ID="Payment-form">
                  <span class="payment-errors"></span>
                  
                  <div class="form-row">
                    <label>
                      <span>Card Number</span>
                      <input type="text" size="20" data-stripe="number"/>
                       </label>
                     </div>
                     
                     <div class="form-row">
                    <label>
                      <span>CVC</span>
                      <input type="text" size="4" data-stripe="cvc"/>
                       </label>
                     </div>
                     
                     <div class="form-row">
                    <label>
                      <span>Expiry Date(MM/YYYY)</span>
                      <input type="text" size="2" data-stripe="exp-month"/>
                       </label>
                       <span> / </span>
                       <input type="text" size="4" data-stripe="exp-year"/>
                     </div>
                     
                     <button type="submit">Submit Payment</button>
                     </form>
                     
                  
                </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
<div class="portfolio-modal modal fade" id="portfolioModal24" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="close-modal" data-dismiss="modal">
            <div class="lr">
              <div class="rl"></div>
            </div>
          </div>
          <div class="container">
            <div class="row">
              <div class="col-lg-8 mx-auto">
                <div class="modal-body">
                
                <form action"" method="POST" ID="Payment-form">
                  <span class="payment-errors"></span>
                  
                  <div class="form-row">
                    <label>
                      <span>Card Number</span>
                      <input type="text" size="20" data-stripe="number"/>
                       </label>
                     </div>
                     
                     <div class="form-row">
                    <label>
                      <span>CVC</span>
                      <input type="text" size="4" data-stripe="cvc"/>
                       </label>
                     </div>
                     
                     <div class="form-row">
                    <label>
                      <span>Expiry Date(MM/YYYY)</span>
                      <input type="text" size="2" data-stripe="exp-month"/>
                       </label>
                       <span> / </span>
                       <input type="text" size="4" data-stripe="exp-year"/>
                     </div>
                     
                     <button type="submit">Submit Payment</button>
                     </form>
                     
                  
                </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Contact Form JavaScript -->
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>

    <!-- Custom scripts for this template -->
    <script src="js/freelancer.min.js"></script>

  </body>

</html>
