<?php
require_once('vendor/autoload.php');

$stripe = array(
  "secret_key"      => "sk_test_xwILpnN02J6MOYXGFHtJHh1N",
  "publishable_key" => "pk_test_tXrujNFlInPAYAoz0AbT6oAY"
);

\Stripe\Stripe::setApiKey($stripe['secret_key']);
?>

<?php require_once('./config.php'); ?>

<form action="charge.php" method="post">
  <script src="https://checkout.stripe.com/checkout.js" class="stripe-button"
          data-key="<?php echo $stripe['sk_test_xwILpnN02J6MOYXGFHtJHh1N']; ?>"
          data-description="Access for a year"
          data-amount="5000"
          data-locale="auto"></script>
</form>