<?php
session_start();

$host="localhost"; // Host name 
$username="richiest1996"; // Mysql username 
$password=""; // Mysql password 
$db_name="users"; // Database name 

// Connect to server and select databse.
mysql_connect("$host", "$username", "$password") or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");
if($_SESSION["myusername"] == null){
header("location: home.php");
}
?>

<html>
<body>
<?php
echo $_SESSION["myusername"];
?>
Login Successful
</body>
</html>