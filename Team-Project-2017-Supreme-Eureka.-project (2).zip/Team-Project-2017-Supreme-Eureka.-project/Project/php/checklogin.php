<?php


session_start();
include 'dbconnect.php';

$host="localhost"; // Host name 
$username="richiest1996"; // Mysql username 
$password=""; // Mysql password 
$db_name="users"; // Database name 
$tbl_name="sponsors"; // Table name 

// Connect to server and select databse.
mysql_connect("$host", "$username", "$password") or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");

// Define $myusername and $mypassword 

if(isset($_POST['login-submit'])){
    $myusername=$_POST['myusername']; 
    $mypassword=$_POST['mypassword']; 
    
    // To protect MySQL injection (more detail about MySQL injection)
    
    $result = $conn -> query("SELECT * FROM ".$tbl_name." WHERE name='".$myusername."' and password='".$mypassword."';");
    $count = 0;
    // Mysql_num_row is counting table row
    $count= $result->num_rows;
    
    // If result matched $myusername and $mypassword, table row must be 1 row
    if($count==1){
    // Register $myusername, $mypassword and redirect to file "login_success.php"
    $_SESSION["myusername"] = $myusername;
    $_SESSION["mypassword"] = $mypassword; 
    header("location:../index.php");
    }
    else {
    echo "Wrong Username or Password";
    }
}
?>
<br>
<a href="../home.php">Back to home page</a>
