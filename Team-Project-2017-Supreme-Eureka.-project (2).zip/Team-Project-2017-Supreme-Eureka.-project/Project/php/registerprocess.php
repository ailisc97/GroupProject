<?php
session_start();
include 'dbconnect.php';
$host = "localhost";
$username = "richiest1996";
$password = "";
$db_name="users";
mysql_connect("$host", "$username", "$password") or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");

if(isset($_POST['register-submit'])){
    $myusername= $_POST["username"]; 
    $myemail= $_POST["email"]; 
    $mypassword= $_POST["password"]; 
    $myconfirmpassword= $_POST["confirmpassword"]; 



    //$result = $conn -> query("INSERT INTO ".$tbl_name." WHERE name='".$myusername."', email='".$myemail."', password='".$mypassword."' and confirmpassword='".$myconfirmpassword."';");
    //$query = $conn -> query("INSERT INTO `sponsor` (`name`, `email`, `password`,`confirmpassword`) VALUES ('$myusername', '$myemail','$mypassword','$myconfirmpassword');";)
    $result = "INSERT INTO `sponsors` (`name`, `email`, `password`,`confirmpassword`) VALUES ('$myusername', '$myemail','$mypassword','$myconfirmpassword');";
 
    $result = mysql_query($result);

 
    $count = 0;
    // Mysql_num_row is counting table row
    $count= $result->num_rows;
    
    if($count==1){
    // Register $myusername, $mypassword and redirect to file "login_success.php"
    $_SESSION["myusername"] = $myusername;
    $_SESSION["myemail"] = $myemail;
    $_SESSION["mypassword"] = $mypassword; 
    $_SESSION["myconfirmpassword"] = $myconfirmpassword;
    header("location:../index.php");
    }
    else {
    //echo "Error try again.";

    }
}
?>
<br>
<a href="../home.php">Back to home page</a>
