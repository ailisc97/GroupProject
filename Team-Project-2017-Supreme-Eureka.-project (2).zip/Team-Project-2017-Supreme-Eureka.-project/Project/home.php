<?php
session_start();
require("php/dbconnect.php")
?>
<!DOCTYPE html>
<html>

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Homeless Support Portal</title>
    
    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css">

    <!-- Custom styles for this template -->
    <link href="css/freelancer.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/form.css" />
	
	 
    <script src="//code.jquery.com/jquery-1.10.2.min.js"></script>
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
    <script type="text/javascript">
    
        window.alert = function(){};
        var defaultCSS = document.getElementById('bootstrap-css');
        function changeCSS(css){
            if(css) $('head > link').filter(':first').replaceWith('<link rel="stylesheet" href="'+ css +'" type="text/css" />'); 
            else $('head > link').filter(':first').replaceWith(defaultCSS); 
        }
        $( document ).ready(function() {
          var iframe_height = parseInt($('html').height()); 
          window.parent.postMessage( iframe_height, 'https://bootsnipp.com');
        });
    </script>
  </head>

  <body id="page-top">

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light fixed-top" id="mainNav">
      <div class="container">
        <a class="navbar-brand js-scroll-trigger" href="#page-top">Homeless Support Portal</a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          Menu
          <i class="fa fa-bars"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#home">Home</a>
            </li>
						<li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#register">Register</a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#aboutus">About Us</a>
            </li>
             <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#successfulstories">Successful Stories</a>
            </li>
            </ul>
             </div>
      </div>
    </nav>
    
      <!-- Header -->
    <header class="masthead" id="home">
      <div class="container">
        <img class="img-fluid" src="photo4.jpeg" alt="">
        <div class="intro-text">
          <span class="name">Homeless Support</span>
          <hr class="star-light">
          <span class="skills">Sponsor - Donate - Message</span>
        </div>
      </div>
    </header>
    
     <section id="register">
        <div class="container">
    	<div class="row">
			<div class="col-md-6 col-md-offset-3">
				<div class="panel panel-login">
					<div class="panel-heading">
						<div class="row">
							<div class="col-xs-6">
								<a href="#" class="active" id="login-form-link">Login</a>
							</div>
							<div class="col-xs-6">
								<a href="#" id="register-form-link">Register</a>
							</div>
						</div>
						<hr>
					</div>
					<div class="panel-body">
						<div class="row">
							<div class="col-lg-12">
								<form id="login-form" action="php/checklogin.php" method="post" role="form" style="display: block;">
									<div class="form-group">
										<input type="text" name="myusername" id="username" tabindex="1" class="form-control" placeholder="Username" value="">
									</div>
									<div class="form-group">
										<input type="password" name="mypassword" id="password" tabindex="2" class="form-control" placeholder="Password">
									</div>
									<div class="form-group text-center">
										<input type="checkbox" tabindex="3" class="" name="remember" id="remember">
										<label for="remember"> Remember Me</label>
									</div>
									<div class="form-group">
										<div class="row">
											<div class="col-sm-6 col-sm-offset-3">
												<input type="submit" name="login-submit" id="login-submit" tabindex="4" class="form-control btn btn-login" value="Log In">
											</div>
										</div>
									</div>
									<div class="form-group">
										<div class="row">
											<div class="col-lg-12">
												<div class="text-center">

												</div>
											</div>
										</div>
									</div>
								</form>
								
								



									<form id="register-form" action="php/registerprocess.php" method="post" role="form" style="display: none;">
									<div class="form-group">
										<input type="text" name="username" id="username" tabindex="1" class="form-control" placeholder="Username" value="">
									</div>
									<div class="form-group">
										<input type="email" name="email" id="email" tabindex="1" class="form-control" placeholder="Email Address" value="">
									</div>
									<div class="form-group">
										<input type="password" name="password" id="password" tabindex="2" class="form-control" placeholder="Password">
									</div>
									<div class="form-group">
										<input type="password" name="confirmpassword" id="confirmpassword" tabindex="2" class="form-control" placeholder="Password">
									</div>
									<div class="form-group">
										<div class="row">
											<div class="col-sm-6 col-sm-offset-3">
												<input type="submit" name="register-submit" id="register-submit" tabindex="4" class="form-control btn btn-register" value="Register Now">
											</div>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	</section>
	
	  <!-- About Section -->
    <section class="success" id="aboutus">
      <div class="container">
        <h2 class="text-center">About Us</h2>
        <hr class="star-light">
        <div class="row">
            <p>Homelessness is a huge problem in Ireland with 8,270 homeless people in August 2017. This figures aren’t just adults with one in three in emergency accommodation is a child, which can be so stressful for the family and the child which can lead to problems in the future with the child. The facts and figures you see aren’t just people on the streets or in emergency accommodation there is the hidden homelessness with is people who are living in squats or sofa surfing.
             Also not included in the figures are woman and children staying in domestic violence refuges.We built this website to help the constant problem of homelessness which is only ever increasing.What makes us different to other charity’s?</p>
			<ul>
			<li>Well we give the option to give money to just one homeless person rather than donating to the charity in general which you are unsure who’s getting the money.</li>
			<li>All donations to the individual homeless person are unbiased.</li>
			<li>We also give the option to purchase hats and scarfs for the homeless people.</li>
			</ul>  
          </div>
        </div>
    </section>
    
    <section id="successfulstories">
		<div class="container" style="width:100%">
			<h2 class="text-center">Successful Stories</h2>
			<hr class="star-primary">
			<div>
			<h3 id = "Casandra">Casandra</h3>
			</div>
			<div class = "row" style="width:100%">
			<div id="markpic" style="width:25%">
			<img src="photo1.jpg">
			</div>
			<div id="marktxt" style="width:75%">
			<p>"The Homeless Supoort Portal saved my life, before i lived on the streets i was an acountaint at Bank of Ireland
			 Now i live under the Shelter of The GPO. The nights are cold but thanks to the help of some generous sponsors i now own
			 a sleeping bag and warm clothes, I usually recive around €12 a week which lets me buy some food. Thank you So much HSP. No hobo tho"</p>
			</div>
	  </div>
			
      <div>
			<h3 id = "James">James</h3>
			</div>
			<div class = "row" style="width:100%">
			<div id="markpic" style="width:25%">
			<img src="photo2.jpeg">
			</div>
			<div id="marktxt" style="width:75%">
			<p>"The Homeless Supoort Portal gave me the opptunity to grow as a person and achieve my goals and actually beating 
			 my deamons and giving me the optunity to give me a roof over my head and gave me food to eat, since that 
			 difficult time in my life I studied in the National College of Ireland and I am now an accountant at KPMG. 
			 I couldnt be happier with my life now. Thanks Homeless Support Portal"</p>
			</div>
	  </div>
			
      <div>
			<h3 id = "Lesbo">Lesbo</h3>
			</div>
			<div class = "row" style="width:100%">
			<div id="markpic" style="width:25%">
			<img src="photo3.jpg">
			</div>
			<div id="marktxt" style="width:75%">
			<p>"The Homeless Supoort Portal gave people like myself a chance in the god damn crule world, I didnt know who ma da was and my mam was a crack whore, 
			 lucky for me and I got out of this bad bad environmentand went to the streets where I was a prostitute, 
			 dam some fellas gave me a lot of crack, I mean cash! but the homeless Suport portal gave me cash with out having to take my clothes off. 
			 I am an independent black woman who dont need no man! I got to meet the love of my life Mary in the homeless support portal, 
			 She was ma sponcer and gave me money but now shes ma lover and my money supplier. 
			 God bless Ireland. yup the d7"</p>
			</div>
	  </div>
			</div>
	</section>
	
	<footer class="text-center">
      <div class="footer-above">
        <div class="container">
          <div class="row">
            <div class="footer-col col-md-4">
              <h3>Location</h3>
              <p>National College of Ireland
                <br>IFSC, Dublin 1, Ireland</p>
            </div>
            <div class="footer-col col-md-4">
              <h3>Around the Web</h3>
              <ul class="list-inline">
                <li class="list-inline-item">
                  <a class="btn-social btn-outline" href="https://www.facebook.com/Homelesssupportportal/ ">
                    <i class="fa fa-fw fa-facebook"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a class="btn-social btn-outline" href="https://twitter.com/homelessupport">
                    <i class="fa fa-fw fa-twitter"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a class="btn-social btn-outline" href="https://www.linkedin.com/in/homeless-support-portal/">
                    <i class="fa fa-fw fa-linkedin"></i>
                  </a>
                </li>
              </ul>
            </div>
            <div class="footer-col col-md-4">
              <h3>Homeless in Ireland</h3>
              <p>Homeless is an issue here in Dublin and we need your help to solve it...</p>
            </div>
          </div>
        </div>
      </div>
      <div class="footer-below">

            <div class="col-lg-12">
              Copyright &copy; Keith Hui(Co-Leader)
			  <br>Ailis Curan (Co-Leader)
			  <br> Richard St Lawrence (Developer)
			  <br> Jonathan Harte (Tester)
            </div>
      </div>
    </footer>

    <!-- Scroll to Top Button (Only visible on small and extra-small screen sizes) -->
    <div class="scroll-top d-lg-none">
      <a class="btn btn-primary js-scroll-trigger" href="#page-top">
        <i class="fa fa-chevron-up"></i>
      </a>
    </div>
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Contact Form JavaScript -->
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>

    <!-- Custom scripts for this template -->
    <script src="js/freelancer.min.js"></script>


    
	</body>
	<script>
	$(function() {
/*global$*/
    $('#login-form-link').click(function(e) {
		$("#login-form").delay(100).fadeIn(100);
 		$("#register-form").fadeOut(100);
		$('#register-form-link').removeClass('active');
		$(this).addClass('active');
		e.preventDefault();
	});
	$('#register-form-link').click(function(e) {
		$("#register-form").delay(100).fadeIn(100);
 		$("#login-form").fadeOut(100);
		$('#login-form-link').removeClass('active');
		$(this).addClass('active');
		e.preventDefault();
	});

});

	</script>
	</html>